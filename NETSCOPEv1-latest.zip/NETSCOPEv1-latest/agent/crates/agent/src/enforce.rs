//! The agent's client to the privileged enforcer (E4) — Unix only.
//!
//! Opt-in: only when `NETSCOPE_ENFORCER_SOCKET` is set does the agent ever reach for
//! enforcement; otherwise NETSCOPE stays generate-only (E3). The agent holds no
//! privilege — it just asks the helper over the authenticated socket, and the helper
//! re-checks everything (including the never-block floor) on its side.

use std::net::IpAddr;
use std::os::unix::net::UnixStream;
use std::time::Duration;

use netscope_enforcer::proto::{read_msg, write_msg, Request, Response};

/// A handle to the configured enforcer socket.
pub struct Enforcer {
    socket: String,
}

impl Enforcer {
    /// Present only when `NETSCOPE_ENFORCER_SOCKET` is configured.
    pub fn from_env() -> Option<Self> {
        std::env::var("NETSCOPE_ENFORCER_SOCKET")
            .ok()
            .filter(|s| !s.trim().is_empty())
            .map(|socket| Enforcer { socket })
    }

    fn round_trip(&self, req: &Request) -> Result<Response, String> {
        let mut conn = UnixStream::connect(&self.socket)
            .map_err(|e| format!("cannot reach enforcer at {}: {e}", self.socket))?;
        let _ = conn.set_read_timeout(Some(Duration::from_secs(5)));
        let _ = conn.set_write_timeout(Some(Duration::from_secs(5)));
        write_msg(&mut conn, req).map_err(|e| format!("sending to enforcer: {e}"))?;
        read_msg::<_, Response>(&mut conn)
            .map_err(|e| format!("reading from enforcer: {e}"))?
            .ok_or_else(|| "enforcer closed without replying".to_string())
    }

    pub fn apply(&self, add: Vec<IpAddr>, remove: Vec<IpAddr>) -> Result<Response, String> {
        self.round_trip(&Request::Apply { add, remove })
    }

    pub fn list(&self) -> Result<Response, String> {
        self.round_trip(&Request::List)
    }

    pub fn clear(&self) -> Result<Response, String> {
        self.round_trip(&Request::Clear)
    }
}
