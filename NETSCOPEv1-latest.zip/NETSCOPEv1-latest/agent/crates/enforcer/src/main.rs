//! `netscope-enforcer` — the privileged helper daemon (E4).
//!
//! Runs as a dedicated service with only `CAP_NET_ADMIN` (see the shipped systemd
//! unit), listens on a Unix socket, and applies block/unblock requests from the
//! agent into its own `inet netscope` nftables table. Configured entirely by env:
//!
//! - `NETSCOPE_ENFORCER_SOCKET`: socket path (default `/run/netscope/enforcer.sock`)
//! - `NETSCOPE_ENFORCER_ALLOW_UID`: UID permitted to drive it; unset ⇒ root only
//! - `NETSCOPE_ENFORCER_MAX_BLOCKED`: block-set cap (default 4096)
//! - `NETSCOPE_ENFORCER_DRY_RUN=1`: validate nft scripts (`nft -c`) without applying,
//!   so the daemon can run unprivileged for a smoke test
//! - `NETSCOPE_ENFORCER_MOCK=1`: keep blocks in memory only (tests/demos)

#[cfg(unix)]
fn main() -> std::process::ExitCode {
    use std::os::unix::fs::PermissionsExt;
    use std::os::unix::net::UnixListener;
    use std::sync::Arc;

    use netscope_enforcer::apply::{Applier, MockApplier, NftApplier};
    use netscope_enforcer::{serve, AllowedPeers, Enforcer, DEFAULT_MAX_BLOCKED};

    let env = |k: &str| std::env::var(k).ok().filter(|s| !s.trim().is_empty());

    let socket_path =
        env("NETSCOPE_ENFORCER_SOCKET").unwrap_or_else(|| "/run/netscope/enforcer.sock".into());
    let allow = match env("NETSCOPE_ENFORCER_ALLOW_UID").and_then(|s| s.parse::<u32>().ok()) {
        Some(uid) => AllowedPeers::Uid(uid),
        None => AllowedPeers::RootOnly,
    };
    let max_blocked = env("NETSCOPE_ENFORCER_MAX_BLOCKED")
        .and_then(|s| s.parse().ok())
        .unwrap_or(DEFAULT_MAX_BLOCKED);
    let dry_run = env("NETSCOPE_ENFORCER_DRY_RUN").is_some();
    // A test affordance: keep blocks in memory only, never touching nft — lets the
    // whole agent→enforcer path be exercised without privilege.
    let mock = env("NETSCOPE_ENFORCER_MOCK").is_some();

    // Ensure the socket's parent directory exists (systemd's RuntimeDirectory does
    // this in production; do it ourselves for ad-hoc runs).
    if let Some(parent) = std::path::Path::new(&socket_path).parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    // A stale socket from a previous run would make bind() fail.
    let _ = std::fs::remove_file(&socket_path);

    let applier: Box<dyn Applier> = if mock {
        Box::new(MockApplier::default())
    } else if dry_run {
        Box::new(NftApplier::checking())
    } else {
        Box::new(NftApplier::new())
    };
    let enforcer = match Enforcer::new(applier, max_blocked) {
        Ok(e) => Arc::new(e),
        Err(e) => {
            eprintln!("[netscope-enforcer] could not initialise firewall: {e}");
            return std::process::ExitCode::FAILURE;
        }
    };

    let listener = match UnixListener::bind(&socket_path) {
        Ok(l) => l,
        Err(e) => {
            eprintln!("[netscope-enforcer] cannot bind {socket_path}: {e}");
            return std::process::ExitCode::FAILURE;
        }
    };
    // The socket is reachable by the unprivileged agent; the SO_PEERCRED check is
    // what authorizes, not the file mode. 0o666 keeps it connectable across users.
    let _ = std::fs::set_permissions(&socket_path, std::fs::Permissions::from_mode(0o666));

    eprintln!(
        "[netscope-enforcer] listening on {socket_path} (allow={allow:?}, cap={max_blocked}, dry_run={dry_run}, mock={mock})"
    );
    serve(listener, enforcer, allow);
}

#[cfg(not(unix))]
fn main() {
    // The Windows enforcer is a separate LocalSystem service (a documented E4
    // follow-up); this Unix-socket daemon does not apply there.
    eprintln!("netscope-enforcer is Linux-only in v1");
}
