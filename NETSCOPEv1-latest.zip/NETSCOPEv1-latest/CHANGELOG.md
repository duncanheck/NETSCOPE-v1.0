# Changelog

Notable changes to NETSCOPE, starting from the run-up to `v1.0.0`. Format loosely
follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/); versioned entries
begin at `v1.0.0`, the project's first tagged release.

## Unreleased

### Fixed
- **Auto-update was silently dead.** The repo's trunk branch is `latest`, not `main` —
  both `desktop-build.yml` and `windows-build.yml` only published their update manifest
  `if: github.ref == 'refs/heads/main'`, so a push to `latest` never published an
  update. Both workflows now trigger on and publish from `latest`.
- **Npcap packet capture was compiled out of the Tauri desktop build.** The bundled
  sidecar agent built without `--features pcap` and without the Npcap SDK on the CI
  runner, so `NETSCOPE_PCAP=1` was a no-op regardless of what was installed on the
  host. `desktop-build.yml` now fetches the Npcap SDK and builds with `--features
  pcap`; the Tauri shell sets `NETSCOPE_PCAP=1` by default when it spawns the sidecar.

### Added
- `SECURITY.md`, `CONTRIBUTING.md`, issue/PR templates, and this changelog.
